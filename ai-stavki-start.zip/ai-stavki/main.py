import os
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import requests

API_KEY = os.getenv("ODDS_API_KEY")

# Первый экономный набор для бесплатного тарифа.
# Потом расширим список, когда проверим расход кредитов.
SPORTS = [
    "soccer_epl",
    "soccer_spain_la_liga",
    "soccer_italy_serie_a",
    "soccer_germany_bundesliga",
    "icehockey_nhl",
    "tennis_atp",
    "tennis_wta",
]

REGIONS = "eu"
MARKETS = "h2h,spreads,totals"
ODDS_FORMAT = "decimal"
DATE_FORMAT = "iso"


def fetch_odds(sport: str) -> list[dict]:
    url = f"https://api.the-odds-api.com/v4/sports/{sport}/odds"
    params = {
        "apiKey": API_KEY,
        "regions": REGIONS,
        "markets": MARKETS,
        "oddsFormat": ODDS_FORMAT,
        "dateFormat": DATE_FORMAT,
    }

    response = requests.get(url, params=params, timeout=30)
    print(f"{sport}: status {response.status_code}")
    print("credits used:", response.headers.get("x-requests-used"))
    print("credits remaining:", response.headers.get("x-requests-remaining"))

    if response.status_code != 200:
        print(response.text)
        return []

    return response.json()


def flatten_events(sport: str, events: list[dict]) -> list[dict]:
    rows = []

    for event in events:
        for bookmaker in event.get("bookmakers", []):
            for market in bookmaker.get("markets", []):
                for outcome in market.get("outcomes", []):
                    rows.append({
                        "sport": sport,
                        "event_id": event.get("id"),
                        "commence_time": event.get("commence_time"),
                        "home_team": event.get("home_team"),
                        "away_team": event.get("away_team"),
                        "bookmaker": bookmaker.get("title"),
                        "bookmaker_key": bookmaker.get("key"),
                        "market": market.get("key"),
                        "outcome": outcome.get("name"),
                        "price": outcome.get("price"),
                        "point": outcome.get("point"),
                        "last_update": bookmaker.get("last_update"),
                    })

    return rows


def main() -> None:
    if not API_KEY:
        raise RuntimeError("ODDS_API_KEY не найден. Проверь GitHub Secret.")

    all_rows = []

    for sport in SPORTS:
        events = fetch_odds(sport)
        all_rows.extend(flatten_events(sport, events))

    reports_dir = Path("reports")
    reports_dir.mkdir(exist_ok=True)

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    csv_path = reports_dir / f"odds_{today}.csv"
    txt_path = reports_dir / f"odds_{today}.txt"

    df = pd.DataFrame(all_rows)
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    with txt_path.open("w", encoding="utf-8") as f:
        f.write("AI Ставки — выгрузка линии The Odds API\n")
        f.write(f"Дата UTC: {today}\n")
        f.write(f"Строк: {len(df)}\n\n")

        if df.empty:
            f.write("Данных нет. Проверь лимит, ключ или выбранные виды спорта.\n")
        else:
            grouped = df.groupby(["sport", "home_team", "away_team", "market"], dropna=False)
            for (sport, home, away, market), group in grouped:
                f.write(f"\n{sport} | {home} — {away} | рынок: {market}\n")
                sample = group.head(12)
                for _, row in sample.iterrows():
                    point = "" if pd.isna(row.get("point")) else f" ({row.get('point')})"
                    f.write(
                        f"  {row.get('bookmaker')}: {row.get('outcome')}{point} — {row.get('price')}\n"
                    )

    print(f"Saved CSV: {csv_path}")
    print(f"Saved TXT: {txt_path}")
    print(f"Rows: {len(df)}")


if __name__ == "__main__":
    main()
